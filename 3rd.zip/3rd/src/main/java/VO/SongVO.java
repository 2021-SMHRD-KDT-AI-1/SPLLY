package VO;

public class SongVO {

}
