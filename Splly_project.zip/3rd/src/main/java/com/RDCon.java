package com;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import DAO.SongDAO;
import VO.PlayListVO;
import VO.SongVO;

public class RDCon implements Command {


	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response) {
		String moveURL="";
		ArrayList<SongVO> song = new ArrayList<SongVO>();
		ArrayList<PlayListVO> rdlist = new ArrayList<PlayListVO>();
		HttpSession session = request.getSession();
		
		String name = request.getParameter("name");
		
		if(name != null)
	         try {
	        	 name = new String(name.getBytes("8859_1"), "EUC-KR");
	            System.out.println(name);
	         } catch (UnsupportedEncodingException e) {
	            // TODO Auto-generated catch block
	            e.printStackTrace();
	         }
		
		
		SongDAO dao = new SongDAO();
		rdlist = dao.RDList();
		
		
		if(song == null) {
	         System.out.println("�÷��̸���Ʈ ���� �ҷ����� ����");
	         moveURL = "main.jsp";
	      }else {
	         session.setAttribute("rdvo", rdlist);
	         //session.setAttribute("playlist", playlist);
	         System.out.println("�뷡 ����Ʈ ���� ����");
	         moveURL = "playlist.jsp";
	      }
	      
	      return moveURL;
		
	}

}
