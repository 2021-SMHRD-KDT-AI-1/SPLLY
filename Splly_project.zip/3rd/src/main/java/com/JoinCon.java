package com;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.Command;

import DAO.memberDAO;
import VO.memberVO;

public class JoinCon implements Command {

	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response) {
		
		String moveURL ="";
		
		
		String id = request.getParameter("id");
		String name = request.getParameter("name");
		String pw = request.getParameter("pw");
		String sns = request.getParameter("sns");
		
	
			memberDAO dao = new memberDAO();
			
			int cnt = dao.Join(id,name,pw,sns);
			// ȸ������ ���ÿ� �α��� ���� �� ���ε� �������� �̵� 
			memberVO vo = dao.Login(id, pw);
			
			if(cnt>0) {
				HttpSession session = request.getSession();
				session.setAttribute("vo", vo);

				moveURL = "join_upload.jsp";
			}
		return moveURL;
	}

}

