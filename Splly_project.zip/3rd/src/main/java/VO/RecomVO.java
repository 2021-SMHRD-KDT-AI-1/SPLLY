package VO;

public class RecomVO {

	int recom_no;
	int photo_no;
	String pli_name;
	String photo;
	
	
	


	public RecomVO(String pli_name, String photo) {
		super();
		this.pli_name = pli_name;
		this.photo = photo;
	}
	
	
	public RecomVO(int recom_no, int photo_no, String pli_name) {
		super();
		this.recom_no = recom_no;
		this.photo_no = photo_no;
		this.pli_name = pli_name;
	}
	
	public int getRecom_no() {
		return recom_no;
	}
	public void setRecom_no(int recom_no) {
		this.recom_no = recom_no;
	}
	public int getPhoto_no() {
		return photo_no;
	}
	public void setPhoto_no(int photo_no) {
		this.photo_no = photo_no;
	}
	public String getPli_name() {
		return pli_name;
	}
	public void setPli_name(String pli_name) {
		this.pli_name = pli_name;
	}
	public String getPhoto() {
		return photo;
	}

	public void setPhoto(String photo) {
		this.photo = photo;
	}
	
	
	
	
}
