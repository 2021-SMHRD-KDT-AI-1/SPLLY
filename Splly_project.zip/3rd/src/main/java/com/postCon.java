package com;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import DAO.comDAO;
import VO.comVO;
import VO.memberVO;

public class postCon implements Command {

	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response) {
		String moveURL = "";
		HttpSession session = request.getSession();
		memberVO vo = (memberVO)session.getAttribute("vo");
		String title = request.getParameter("title");
		String selectimg = request.getParameter("selectimg");
		String contents = request.getParameter("contents");
		
		System.out.println("�̹��� �� : " + selectimg);
		
		comDAO com = new comDAO();
		int cnt = com.addpost(title, contents, vo.getId(), selectimg);
		
		if (cnt > 0) {
			
			moveURL = "com_main.jsp";
			System.out.println("��");
		}
		return moveURL;
	}

}
