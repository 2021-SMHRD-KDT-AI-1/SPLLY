package DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import VO.PlayListVO;
import VO.comVO;
import VO.memberVO;
import VO.uploadVO;

public class comDAO {

	Connection conn = null;
	PreparedStatement psmt = null;
	ResultSet rs = null;

	String sql = "";
	int cnt = 0;
	comVO com = null;
	
    ArrayList<uploadVO> list = new ArrayList<uploadVO>();

	public void getConn() {

		try {

			Class.forName("oracle.jdbc.driver.OracleDriver");

			String url = "jdbc:oracle:thin:@127.0.0.1:1521";
			String dbid = "hr";
			String dbpw = "hr";
			conn = DriverManager.getConnection(url, dbid, dbpw);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void close() {
		try {
			if (rs != null) {
				rs.close();
			}
			if (psmt != null) {
				psmt.close();
			}
			if (conn != null) {
				conn.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	public int addpost(String title,String contents, String id, String selectimg) {
		
		getConn();
		
		sql = "insert into sns_post values(post_no.nextval, ?, ?, ?, sysdate, null, ?)";
		
		try {
			psmt = conn.prepareStatement(sql);
			
			psmt.setString(1, title);
			psmt.setString(2, contents);
			psmt.setString(3, id);
			psmt.setString(4, selectimg);
			
			cnt = psmt.executeUpdate();
			
	
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			close();
		} return cnt;
		
	}
	
public ArrayList<comVO> post() {
		ArrayList<comVO> arr = new ArrayList<comVO>();
		getConn();
		
		sql = "select * from sns_post";
		
		try {
			psmt = conn.prepareStatement(sql);
		
			rs = psmt.executeQuery();
			
		while(rs.next()) {
				int getpost_no = rs.getInt(1);
				String getpost_title= rs.getString(2);
				String getcontents= rs.getString(3);
				String getuser_id= rs.getString(4);
				String getpost_date= rs.getString(5);
				int getphoto_no= rs.getInt(7);
				
				com = new comVO(getpost_no, getpost_title, getcontents, getuser_id, getpost_date, getphoto_no);

				arr.add(com);
			 }
		}catch (Exception e) {
			e.printStackTrace();
		} finally {
			close();
		} return arr;
		
	}

	
public ArrayList<uploadVO> imgfind(int id) {
		
		getConn();
		
		sql = "select * from user_photo where user_no = ?";
		
		try {
			psmt = conn.prepareStatement(sql);
		
			psmt.setInt(1, id);			
			rs = psmt.executeQuery();
			
		while(rs.next()) {
				
				int photo_no = rs.getInt(1);
				String photo_url = rs.getString(2);
				uploadVO photo = new uploadVO(photo_no,photo_url);
				list.add(photo);
				System.out.println(list);
			 }
		}catch (Exception e) {
			e.printStackTrace();
		} finally {
			close();
		} return list;
		
	}

public uploadVO postimg(int number) {
	uploadVO photo = null;
	getConn();
	
	sql = "select * from user_photo where photo_no = ?";
	
	try {
		psmt = conn.prepareStatement(sql);
	
		psmt.setInt(1, number);			
		rs = psmt.executeQuery();
		
	while(rs.next()) {
			
			int photo_no = rs.getInt(1);
			String photo_url = rs.getString(2);
			photo = new uploadVO(photo_no,photo_url);
			list.add(photo);
			System.out.println(list);
		 }
	}catch (Exception e) {
		e.printStackTrace();
	} finally {
		close();
	} return photo;
	
}
public comVO OnePost(int no){
	
	try {
		getConn();
		sql = "select * from sns_post where post_no = ?";
		psmt = conn.prepareStatement(sql);
		psmt.setInt(1, no);
		rs = psmt.executeQuery();
		while(rs.next()) {
			int getpost_no = rs.getInt(1);
			String getpost_title= rs.getString(2);
			String getcontents= rs.getString(3);
			String getuser_id= rs.getString(4);
			String getpost_date= rs.getString(5);
			int getphoto_no= rs.getInt(7);
			com = new comVO(getpost_no, getpost_title, getcontents, getuser_id, getpost_date, getphoto_no);
		}
	} catch (Exception e) {
		e.printStackTrace();
		
	}finally {
		close();
	}
	return com;
	
	
}

private uploadVO uploadVO(int photo_no, String photo_url) {
	// TODO Auto-generated method stub
	return null;
}

	
	
	

	
	

	
	
}