package com;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import DAO.SongDAO;
import VO.PlayListVO;
import VO.SongVO;

public class PlayListCon implements Command {


	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response) {
		String moveURL;
		HttpSession session = request.getSession();
		ArrayList<SongVO> song = new ArrayList<SongVO>();
		SongDAO dao = new SongDAO();
		String name = request.getParameter("name");
		name = name.replace("//", "#");
		System.out.println(name);
		PlayListVO playlist = null;

//		if(name != null) {
//			try {
//				name = new String(name.getBytes("8859_1"), "utf-8");
//				System.out.println(name);
//			} catch (UnsupportedEncodingException e) {
//				e.printStackTrace();
//			}
//		}
		song = dao.SongList(name);
		playlist = dao.OnePlist(name);
		
		if(song == null) {
			System.out.println("�÷��̸���Ʈ �뷡 ���� �ҷ����� ����");
			moveURL = "main.jsp";
		}else {
			session.setAttribute("songvo", song);
			session.setAttribute("playlist", playlist);
			System.out.println("�뷡 ����Ʈ ���� ����");
			moveURL = "detail_Play.jsp";
		}
		
		return moveURL;
	}

}
