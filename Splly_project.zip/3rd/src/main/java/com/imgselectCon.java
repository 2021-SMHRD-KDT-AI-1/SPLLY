package com;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import DAO.RecomDAO;
import DAO.SongDAO;
import DAO.uploadDAO;
import VO.PlayListVO;
import VO.RecomVO;
import VO.memberVO;
import VO.uploadVO;

public class imgselectCon implements Command  {

	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response) {
		//DB�� ����� file������ ��� �˻��ؼ� jsp�� ����
		
		String moveURL= "";
		ArrayList<String> pname = new ArrayList<String>();
		try{
			uploadDAO dao = new uploadDAO();
			SongDAO song = new SongDAO();
			RecomDAO recom = new RecomDAO();
			HttpSession session = request.getSession();
			memberVO vo = (memberVO)session.getAttribute("vo");
			
			String tag1 = request.getParameter("tag1");
			String tag2 = request.getParameter("tag2");
			String tag3 = request.getParameter("tag3");
			
			String tag = tag1 + "," + tag2 + "," + tag3;

			int cnt = dao.Update(tag, vo.getUser_no());

			ArrayList<uploadVO> upload = (ArrayList<uploadVO>)dao.SelectOne(vo.getUser_no());
			ArrayList<PlayListVO> rand = (ArrayList<PlayListVO>)song.RANDList(tag1, tag2, tag3);
			
			for(int i=0; i<rand.size();i++){
				String ran = rand.get(i).getPlaylist_name();
				pname.add(ran);
			}
			
			for(int i = 0; i<rand.size();i++){
				recom.Recominput(upload.get(1).getPhoto_no(), pname.get(i));
			}
			
			if (cnt > 0) {
				moveURL = "result.jsp";
				session.setAttribute("upload", upload);
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		} return moveURL;
	
	
	}

}
