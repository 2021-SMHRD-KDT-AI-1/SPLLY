package DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Random;

import org.apache.catalina.connector.Request;

import VO.PlayListVO;
import VO.SongVO;

public class weatherDAO {
	
//	  String wanted = (String) session.getAttribute(wanted);//FOOD ���� ������ ������


//      String animal = request.getParameter(����);//ANIMAL�Ķ���� ������


//       session.invalidate();//���� ����


	
	
	
	Connection conn = null;
	PreparedStatement psmt = null;

	int cnt = 0;
	String sql = "";
	PlayListVO vo = null;
	PlayListVO vo1 =null;
	ResultSet rs = null;
	
	public void getConn() {

		try {

			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url = "jdbc:oracle:thin:@127.0.0.1:1521";
			String dbid = "hr";
			String dbpw = "hr";
			conn = DriverManager.getConnection(url, dbid, dbpw);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void close() {
		try {

			if (rs != null) {
				rs.close();
			}
			if (psmt != null) {
				psmt.close();
			}
			if (conn != null) {
				conn.close();
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	} 
	

	public ArrayList<PlayListVO> WEList(int num){
		ArrayList<PlayListVO> arr = new ArrayList<PlayListVO>();
		getConn();
		
          //���⿡ ���� �������� sql�� 	���ǿ� �°� �۵� 
		
		
           if(num == 1 || num == 4 || num == 5) {
        	   sql = "select * from playlist where song_tag like '%�帶%' "
  					+ "or song_tag like '%��ġ�ϰ�%'"
   					+ "and song_tag like '%,��%'";
        	   
           }else if (num == 2 || num == 3 || num == 6 || num == 7) {
        	   sql = "select * from playlist where song_tag like '%��%' "
   					+ "or song_tag like '%�ܿ�%'"
   					+ "and song_tag like '%ĳ��%'";
        	   
           }else if(num == 0 ) {
        	   sql = "select * from playlist where song_tag like '%û��%' "
      					+ "or song_tag like '%��Ʈ�����ؼ�%'"
      					+ "and song_tag like '%�����ȯ%'";
           }
           		
		
			try {
				getConn();
				psmt = conn.prepareStatement(sql);
				//psmt.setString(1, tag1);
				//psmt.setString(2, tag2);
				//psmt.setString(3, tag3);
				rs = psmt.executeQuery();
				
				while(rs.next()) {
					String playlist_name = rs.getString(2);
					String playlist_tag = rs.getString(3);
					vo = new PlayListVO(playlist_name,playlist_tag);
					arr.add(vo);
			}
				
			}
		 catch (Exception e) {
			e.printStackTrace();
			
		}finally {
			close();
		
		return arr;
	}
			
			
			
	
		

	}
}
