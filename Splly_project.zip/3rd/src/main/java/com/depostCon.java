package com;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import DAO.comDAO;
import VO.comVO;

public class depostCon implements Command {

	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response) {
		
		String moveURL;
		HttpSession session = request.getSession();
		int num = Integer.parseInt(request.getParameter("num"));
		comDAO dao = new comDAO();
		comVO one = dao.OnePost(num);
		System.out.println(num);
		
		
		if(one == null) {
			System.out.println("�Խñ� �������� ����");
			moveURL = "com_main.jsp";
		}else {
			session.setAttribute("one", one);
			System.out.println("�Խñ� ���� ����");
			moveURL = "com.jsp";
		}
		
		return moveURL;
	}

}
