package DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import VO.RecomVO;
import VO.memberVO;

public class RecomDAO {
	
	Connection conn = null;
	PreparedStatement psmt = null;

	int cnt = 0;
	String sql = "";
	RecomVO vo = null;
	ResultSet rs = null;

	public void getConn() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url = "jdbc:oracle:thin:@127.0.0.1:1521";
			String dbid = "hr";
			String dbpw = "hr";
			conn = DriverManager.getConnection(url, dbid, dbpw);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public void close() {
		
		try {
			if(rs!=null) {
				rs.close();
			}
			if(psmt!=null) {
				psmt.close();
			}
			if(conn!=null) {
				conn.close();
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public int Recominput(int photo_no, String pli_name) {

		try {
			
			getConn();

			sql = "insert into recommend_list values(recommend_no.NEXTVAL,?,?)";

			psmt = conn.prepareStatement(sql);
			psmt.setInt(1, photo_no);
			psmt.setString(2, pli_name);

			cnt = psmt.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			close();
		}
		return cnt;
	}
	
	public ArrayList<RecomVO> select(int photo_no) {
		ArrayList<RecomVO> arr = new ArrayList<RecomVO>();
		try {
			getConn();
			sql = "select * from RECOMMEND_LIST where photo_no = ?";
			psmt = conn.prepareStatement(sql);
			psmt.setInt(1, photo_no);
			rs = psmt.executeQuery();

			while (rs.next()) {
				String pli_name = rs.getString(3);
				String photo = rs.getString(2);
				
				
				vo = new RecomVO(pli_name,photo);

				arr.add(vo);
			}
		} catch (Exception e) {
			e.printStackTrace();
			
		}finally {
			
			close();
		}
		return arr;
	}
}
